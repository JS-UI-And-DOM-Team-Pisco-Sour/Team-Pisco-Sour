define(function () {
   return {
       WIDTH: 99.2,
       HEIGHT: 111,
       RADIUS: 30,
       FRAME_COUNT: 10,
       SPAWN_FRAME_INTERVAL: 25,
       SPEED: 3,
       SCALE: 0.6
   }
});