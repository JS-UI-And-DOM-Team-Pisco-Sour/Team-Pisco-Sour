define(function () {
    return {
        STAGE_WIDTH: 0.7 * window.innerWidth,
        STAGE_HEIGHT: 0.9 * window.innerHeight,

        KEYS: {
            A: 65,
            E: 69,
            Q: 81,
            W: 87
        }
    }
});